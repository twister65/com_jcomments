DROP TABLE IF EXISTS #__jcomments;

DROP TABLE IF EXISTS #__jcomments_settings;

DROP TABLE IF EXISTS #__jcomments_votes;

DROP TABLE IF EXISTS #__jcomments_subscriptions;

DROP TABLE IF EXISTS #__jcomments_version;

DROP TABLE IF EXISTS #__jcomments_custom_bbcodes;

DROP TABLE IF EXISTS #__jcomments_reports;

DROP TABLE IF EXISTS #__jcomments_blacklist;

DROP TABLE IF EXISTS #__jcomments_objects;

DROP TABLE IF EXISTS #__jcomments_mailq;

DROP TABLE IF EXISTS #__jcomments_smilies;

